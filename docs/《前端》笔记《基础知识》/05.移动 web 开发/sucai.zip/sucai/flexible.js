/* 移动端适配库 

rem 适配布局（技术方案二）（推荐）

原理：flexible.js（移动端适配库）+ rem
官网：https://github.com/amfe/lib-flexible
原理：使用 rem 替代 px
优点：
  1、无需定义不同屏幕的媒体查询
  2、等比例缩放页面

设计稿尺寸：750px
1rem = html 字体大小;
元素rem值 = 元素px / html字体大小

使用步骤：
  1、引入 flexible.js 
  2、定义 屏幕划分份数：10份（默认）
  3、定义 html字体大小：75px（html字体大小 = 设计稿尺寸 / 屏幕划分份数）
  4、定义 cssrem 插件 html字体大小
  5、定义 html 最大宽度 */

;(function flexible(window, document) {
  var docEl = document.documentElement
  var dpr = window.devicePixelRatio || 1

  // adjust body font size
  function setBodyFontSize() {
    if (document.body) {
      document.body.style.fontSize = 12 * dpr + 'px'
    } else {
      document.addEventListener('DOMContentLoaded', setBodyFontSize)
    }
  }
  setBodyFontSize()

  // set 1rem = viewWidth / 10
  function setRemUnit() {
    var rem = docEl.clientWidth / 10
    docEl.style.fontSize = rem + 'px'
  }

  setRemUnit()

  // reset rem unit on page resize
  window.addEventListener('resize', setRemUnit)
  window.addEventListener('pageshow', function (e) {
    if (e.persisted) {
      setRemUnit()
    }
  })

  // detect 0.5px supports
  if (dpr >= 2) {
    var fakeBody = document.createElement('body')
    var testElement = document.createElement('div')
    testElement.style.border = '.5px solid transparent'
    fakeBody.appendChild(testElement)
    docEl.appendChild(fakeBody)
    if (testElement.offsetHeight === 1) {
      docEl.classList.add('hairlines')
    }
    docEl.removeChild(fakeBody)
  }
})(window, document)
